#!/usr/bin/env python3
import argparse


def main():
    parser = argparse.ArgumentParser(
        description='Compares two configuration files and shows a difference.',
        add_help=False
    )

    parser.add_argument('first_file', help='Path to the first configuration file')
    parser.add_argument('second_file', help='Path to the second configuration file')

    parser.add_argument(
        '-f', '--format',
        help='set format of output',
        default='stylish',
        choices=['stylish', 'plain', 'json'],
        metavar='FORMAT'
    )

    parser.add_argument('-h', '--help', action='help', help='show this help message and exit')

    args = parser.parse_args()

    print(f"Comparing {args.first_file} and {args.second_file}")
    print(f"Output format: {args.format}")


if __name__ == '__main__':
    main()